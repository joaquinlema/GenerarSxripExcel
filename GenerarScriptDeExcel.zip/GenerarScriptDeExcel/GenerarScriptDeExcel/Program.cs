﻿using ExcelDataReader;
using GenerarScriptDeExcel.Models;
using System;
using System.Collections.Generic;
using System.IO;


namespace GenerarScriptDeExcel
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\Users\sebastian.capurro\Desktop\DataForScript.xlsx"; // args[0]; modificar excel de donde leer los registros a agregar
            System.Text.StringBuilder csv = new System.Text.StringBuilder();
            var filename = "";
            int contador = 0;
            List<string> fields = new List<string>();
            List<People> persons = new List<People>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    do
                    {
                        while (reader.Read())
                        {
                            if (contador == 0)
                            {
                                //obtenemos los campos a insertar ( cabecera del excel id,centreId,..)
                                fields.AddRange(new List<string>(){reader.GetString(0),
                                 reader.GetString(1),
                                 reader.GetString(2),
                                 reader.GetString(3),
                                 reader.GetString(4),
                                 reader.GetString(5),
                                 reader.GetString(6),
                                 reader.GetString(7),
                                 reader.GetString(8),
                                 reader.GetString(9),
                                 reader.GetString(10),
                                 reader.GetString(11),
                                 reader.GetString(12),
                                 reader.GetString(13),
                                     "LastSync",
                                 reader.GetString(14),
                                 reader.GetString(15),
                                 reader.GetString(16),
                                 reader.GetString(17),
                                 reader.GetString(18),
                                 reader.GetString(19) });


                                contador++;
                            }
                            else
                            {
                                //obtenemos los values

                                People p = new People();
                                p.Id = reader.GetValue(0).ToString();
                                p.CentreId = reader.GetValue(1).ToString();
                                p.RecordSource = reader.GetValue(2).ToString();
                                p.SAPPersonId = reader.GetValue(3).ToString();
                                p.CobraEmployeeId = reader.GetValue(4).ToString();
                                p.CobraBusinessId = reader.GetValue(5).ToString();
                                p.FullName = reader.GetValue(6).ToString();
                                p.ValidFrom = Convert.ToDateTime(reader.GetValue(7).ToString()).ToString("yyyy-MM-dd");
                                p.ValidTo = reader.GetValue(8).ToString() != "NULL"? Convert.ToDateTime(reader.GetValue(8).ToString()).ToString("yyyy-MM-dd"): reader.GetValue(8).ToString();
                                p.IsGuest = reader.GetValue(9).ToString();
                                p.Remark = reader.GetValue(10).ToString();
                                p.RecordDate = reader.GetValue(11).ToString();
                                p.RegTmpo = reader.GetValue(12).ToString();
                                p.LastUpdate = Convert.ToDateTime(reader.GetValue(13).ToString()).ToString("yyyy-MM-dd HH:mm:ss");// reader.GetValue(13).ToString();
                                p.Manager = reader.GetValue(14).ToString();
                                p.CompanyId = reader.GetValue(15).ToString();
                                p.Job = reader.GetValue(16).ToString();
                                p.AccessReasonId = reader.GetValue(17).ToString();
                                p.AuthorizedBy = reader.GetValue(18).ToString();
                                p.Deleted = reader.GetValue(19).ToString();
                                persons.Add(p);

                            }


                        }

                    } while (reader.NextResult());
                }
                //Recorremos la lista de personas(values) y armamos el script
                foreach (var i in persons)
                {

                    AppendPersonToList(i, fields, ref csv);
                }
                filename = string.Format("{0}.sql", "AddToOP"); //args[1];
                System.IO.File.WriteAllText(System.IO.Path.Combine("C:\\Users\\sebastian.capurro\\Desktop", filename), csv.ToString()); //modificar path a guardar y name de script
            }


            Console.ReadKey();
        }

        static void AppendPersonToList(People person,List<string> fields, ref System.Text.StringBuilder csv)
        {
            csv.AppendLine($"INSERT INTO PEOPLE ({string.Join(",", fields).Trim()}) VALUES ({person.Id},{person.CentreId},'{ person.RecordSource }','{person.SAPPersonId}',{person.CobraEmployeeId},{person.CobraBusinessId},'{person.FullName}','{person.ValidFrom}','{person.ValidTo}',{person.IsGuest},'{person.Remark}',GETDATE(),'{person.RegTmpo}','{person.LastUpdate}',NULL,'{person.Manager}',{person.CompanyId},'{person.Job}',{person.AccessReasonId},'{person.AuthorizedBy}',{person.Deleted});\n");
        }



    }
}
