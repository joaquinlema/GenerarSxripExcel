﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerarScriptDeExcel.Models
{
    public class People
    {
        public string Id { get; set; }
        public string CentreId { get; set; }
        public string RecordSource { get; set; }
        public string SAPPersonId { get; set; }
        public string CobraEmployeeId { get; set; }
        public string CobraBusinessId { get; set; }
        public string FullName { get; set; }
        public string ValidFrom { get; set; }
        public string ValidTo { get; set; }
        public string IsGuest { get; set; }
        public string Remark { get; set; }
        public string RecordDate { get; set; }
        public string RegTmpo { get; set; }
        public string LastUpdate { get; set; }
        public string Manager { get; set; }
        public string CompanyId { get; set; }
        public string Job { get; set; }
        public string AccessReasonId { get; set; }
        public string AuthorizedBy { get; set; }
        public string Deleted { get; set; }

    }
}
